

<img src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgzGHFePffN9pWKDHqoMNKNOOCrWN3Gj7DNpCwEqYsnu_aNwI9HpZDeDKXw9cRW6bhn0kiW0q4cYoiUjk47urcS5JUSZ9fjU4ekLdGNI7Z91cNv6JV33499W_DD9pO_E9CrGlBDzhSsjYUh2nl2yMpj4bBtufabrSEoGLNWHVnh8r9LHrViHToYzbRIZg/s1280/Tutorial%20Membuat%20Aplikasi%20Absensi%20dengan%20Android%20Studio.png" data-canonical-src="https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEgzGHFePffN9pWKDHqoMNKNOOCrWN3Gj7DNpCwEqYsnu_aNwI9HpZDeDKXw9cRW6bhn0kiW0q4cYoiUjk47urcS5JUSZ9fjU4ekLdGNI7Z91cNv6JV33499W_DD9pO_E9CrGlBDzhSsjYUh2nl2yMpj4bBtufabrSEoGLNWHVnh8r9LHrViHToYzbRIZg/s1280/Tutorial%20Membuat%20Aplikasi%20Absensi%20dengan%20Android%20Studio.png" style="max-width:100%;">







```
Copyright (C) Azhar Rivaldi

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.

```
